from django.urls import path

app_name = 'marksheets'

urlpatterns = [
    # Marksheets are accessed via students app
]
