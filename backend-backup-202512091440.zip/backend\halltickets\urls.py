from django.urls import path

app_name = 'halltickets'

urlpatterns = [
    # Halltickets are accessed via students app
]
